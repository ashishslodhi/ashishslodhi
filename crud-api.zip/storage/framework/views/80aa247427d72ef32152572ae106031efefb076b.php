<!DOCTYPE html>
<html>
<head>
    <style>
        /* Customize your footer styles here */
        .footer {
            text-align: center;
            font-size: 10px;
        }
    </style>
</head>
<body>
    <div class="footer">
        This is the footer of the PDF - Page {PAGE_NUM}/{PAGE_COUNT}
    </div>
</body>
</html><?php /**PATH C:\Users\Lod21A846\OneDrive - XS CAD\Desktop\Ashish\development\me\laravel\crud-api\resources\views/footer.blade.php ENDPATH**/ ?>