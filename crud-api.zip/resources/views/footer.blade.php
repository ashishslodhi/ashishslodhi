<!DOCTYPE html>
<html>
<head>
    <style>
        /* Customize your footer styles here */
        .footer {
            text-align: center;
            font-size: 10px;
        }
    </style>
</head>
<body>
    <div class="footer">
        This is the footer of the PDF - Page {PAGE_NUM}/{PAGE_COUNT}
    </div>
</body>
</html>