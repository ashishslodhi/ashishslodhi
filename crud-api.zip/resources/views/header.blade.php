<!DOCTYPE html>
<html>
<head>
    <style>
        /* Customize your header styles here */
        .header {
            text-align: center;
            font-weight: bold;
        }
    </style>
</head>
<body>
    <div class="header">
        This is the header of the PDF
    </div>
</body>
</html>