<!DOCTYPE html>
<html>
<head>
    <style>
        /* Customize your header styles here */
        .header {
            text-align: center;
            font-weight: bold;
        }
    </style>
</head>
<body>
    <div class="header">
        This is the header of the PDF
    </div>
</body>
</html><?php /**PATH C:\Users\Lod21A846\OneDrive - XS CAD\Desktop\Ashish\development\me\laravel\crud-api\resources\views/header.blade.php ENDPATH**/ ?>